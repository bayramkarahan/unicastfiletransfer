#ifndef FILECLIENT_H
#define FILECLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <QFile>

class FileClient : public QObject
{
    Q_OBJECT

public:
    explicit FileClient(QObject *parent = nullptr);

    void connectToServer(QString ip, quint16 port);
    void sendFile(QString filepath, QString receiver);

signals:
    void transferFinished(QString sender,
                          QString receiver,
                          QString filename);
    void connected();

private slots:
    void onReadyRead();
private:
    QTcpSocket socket;
};

#endif
