#include<unicastfiletransferclient.h>
#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    FileClient client;

        QObject::connect(&client,&FileClient::transferFinished,
        [](QString sender, QString receiver, QString file)
        {
            qDebug() << sender << "->" << receiver << file << "gönderildi";
        });


        QObject::connect(&client,&FileClient::connected,[&]()
        {
            client.sendFile("/home/etapadmin/ab.deb","192.168.1.100");
        });

        client.connectToServer("192.168.1.100",45454);

    return a.exec();
}
