#include "unicastfiletransferclient.h"
#include <QFileInfo>
#include <QHostAddress>
FileClient::FileClient(QObject *parent) : QObject(parent)
{
    connect(&socket,&QTcpSocket::connected,
            this,&FileClient::connected);

    connect(&socket,&QTcpSocket::readyRead,
            this,&FileClient::onReadyRead);
}

void FileClient::connectToServer(QString ip, quint16 port)
{
    socket.connectToHost(ip, port);
}

void FileClient::onReadyRead()
{
    QByteArray data = socket.readAll();

    QString msg(data);

    if(msg.startsWith("TRANSFER_DONE"))
    {
        QStringList parts = msg.split("|");

        QString sender = parts[1];
        QString receiver = parts[2];
        QString filename = parts[3].trimmed();

        emit transferFinished(sender,receiver,filename);
    }
}

void FileClient::sendFile(QString filepath, QString receiver)
{
    QFile file(filepath);

    if(!file.open(QIODevice::ReadOnly))
        return;

    QFileInfo info(file);

    QString sender = socket.localAddress().toString();

    QString header =
        QString("FILE_INFO|%1|%2|%3|%4\n")
        .arg(sender)
        .arg(receiver)
        .arg(info.fileName())
        .arg(file.size());

    socket.write(header.toUtf8());

    while(!file.atEnd())
    {
        QByteArray chunk = file.read(64*1024);
        socket.write(chunk);
        socket.waitForBytesWritten();
    }

    //emit transferFinished(sender,receiver,info.fileName());
}
