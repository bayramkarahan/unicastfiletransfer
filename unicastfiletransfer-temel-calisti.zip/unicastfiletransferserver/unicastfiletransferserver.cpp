#include "unicastfiletransferserver.h"
#include <QDebug>

FileServer::FileServer(QObject *parent)
    : QTcpServer(parent)
{
}

void FileServer::startServer(quint16 port)
{
    if(listen(QHostAddress::Any, port))
        qDebug() << "Server started";
}

void FileServer::incomingConnection(qintptr socketDescriptor)
{
    QTcpSocket *socket = new QTcpSocket(this);
    socket->setSocketDescriptor(socketDescriptor);

    connect(socket, &QTcpSocket::readyRead, [socket,this]()
    {
        static QFile file;
        static qint64 bytesReceived = 0;
        static qint64 fileSize = 0;

        if(fileSize == 0)
        {
            QByteArray header = socket->readLine();
            QString msg(header);

            QStringList parts = msg.split("|");

            QString sender = parts[1];
            QString receiver = parts[2];
            QString filename = parts[3];
            fileSize = parts[4].trimmed().toLongLong();

            //file.setFileName("received_" + filename);
            file.setFileName( filename);
            file.open(QIODevice::WriteOnly);

            bytesReceived = 0;

            qDebug() << "Receiving file from" << sender;
        }

        QByteArray data = socket->readAll();
        file.write(data);

        bytesReceived += data.size();

        if(bytesReceived >= fileSize)
        {
            file.close();

            QString sender = socket->peerAddress().toString();
            QString receiver = "SERVER";

            emit transferCompleted(sender, receiver, file.fileName());

            QString msg = QString("TRANSFER_DONE|%1|%2|%3\n")
                          .arg(sender)
                          .arg(receiver)
                          .arg(file.fileName());

            socket->write(msg.toUtf8());

            fileSize = 0;
        }

    });
}
