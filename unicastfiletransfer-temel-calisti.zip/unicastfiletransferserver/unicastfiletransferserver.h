#ifndef FILESERVER_H
#define FILESERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QFile>

class FileServer : public QTcpServer
{
    Q_OBJECT

public:
    explicit FileServer(QObject *parent = nullptr);
    void startServer(quint16 port);

signals:
    void transferCompleted(QString sender,
                           QString receiver,
                           QString filename);

protected:
    void incomingConnection(qintptr socketDescriptor) override;

};

#endif
