#include "unicastfiletransferserver.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    FileServer server;

    server.startServer(45454);

    QObject::connect(&server,&FileServer::transferCompleted,
    [](QString sender, QString receiver, QString file)
    {
        qDebug() << sender << "->" << receiver << file;
    });
      return a.exec();
}
